
let armas = [
{nome : "Doze" , dano : 30},
{nome : "Arco" , dano : 20},
{nome : "Faca" , dano : 15}];

let inimigos = [
{ID : "Id001" ,nome : "Goblin" , vida : 70 , dano : 15 ,xp : 30},
{ID : "Id002" ,nome : "Ogro" , vida : 150 , dano : 35 ,xp : 80},
{ID : "Id003" ,nome : "Slime" , vida : 10 , dano : 5 ,xp : 20}];

let players = [
{nome : "Flazi" , vida : 100},
{nome : "Chat" , vida : 100}]

let Id001 = inimigos[0]

function mostrarStatus(inimigos , players) {
let Id001 = inimigos[0]; // apenas inimigos tem ID
let player = players[1];

console.log("Nome do inimigo : " + Id001.nome +  " | Vida do inimigo : " + Id001.vida)
console.log("Seu nome : " + player.nome + " | Sua Vida : " + player.vida)
};

function atacar(armas , Id001) {
  let arma = armas[0]
  while (Id001.vida > 0){
  console.log("Voce atacou o " + Id001.nome + " usando " + arma.nome);
  Id001.vida -= arma.dano
  console.log("Vida do " + Id001.nome + " é : " + Id001.vida)
  }
  console.log(Id001.nome + " derrotado")
}
mostrarStatus(inimigos , players);
atacar(armas , Id001);
