document.getElementById('runButton').addEventListener('click', function() {
  const html = document.getElementById('html').value;
  const css = `<style>${document.getElementById('css').value}</style>`;
  const js = `<script>${document.getElementById('js').value}<\/script>`;

  const iframe = document.getElementById('preview');
  const doc = iframe.contentDocument || iframe.contentWindow.document;

  doc.open();
  doc.write(html + css + js);
  doc.close();
});

function inserirEstrutura(tipo) {
  if (tipo === 'html') {
    document.getElementById('html').value = `<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Título</title>
</head>
<body>

  <h1>Olá Mundo!</h1>

</body>
</html>`;
  }

  if (tipo === 'css') {
    document.getElementById('css').value = `body {
  font-family: Arial, sans-serif;
  background: #f0f0f0;
  color: #333;
  text-align: center;
}`;
  }

  if (tipo === 'js') {
    document.getElementById('js').value = `document.addEventListener('DOMContentLoaded', function() {
  alert("Página carregada com sucesso!");
});`;
  }
}